#ifndef _WEBBENCH_SOCKET
#define _WEBBENCH_SOCKET

int Socket(const char *host, int clientPort);
#endif
